package mx.utng.s34;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProuyectoCreadoDeSdeWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProuyectoCreadoDeSdeWebApplication.class, args);
	}

}
