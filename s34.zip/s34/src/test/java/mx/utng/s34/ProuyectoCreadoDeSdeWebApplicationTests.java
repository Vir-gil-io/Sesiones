package mx.utng.s34;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProuyectoCreadoDeSdeWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
