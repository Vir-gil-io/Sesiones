package mx.utng.pd.absfactory;

public interface Camioneta {
    String getNombre();
    String getCaracteristicas();
    
}
