package mx.utng.pd.absfactory;

public interface Auto {
    String getNombre();
    String getCaracteristicas();
    
}
