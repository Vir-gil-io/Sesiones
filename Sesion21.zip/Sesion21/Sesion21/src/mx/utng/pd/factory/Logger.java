package mx.utng.pd.factory;

public interface Logger{
    void log(String msg);
    
}