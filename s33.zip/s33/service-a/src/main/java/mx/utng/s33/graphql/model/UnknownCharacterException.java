package mx.utng.s33.graphql.model;

@SuppressWarnings("serial")
public class UnknownCharacterException extends Exception {

    public UnknownCharacterException(String message) {
        super(message);
    }

}
