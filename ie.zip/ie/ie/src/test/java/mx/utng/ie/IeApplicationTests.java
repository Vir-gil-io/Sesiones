package mx.utng.ie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IeApplicationTests {

	@Test
	void contextLoads() {
	}

}
